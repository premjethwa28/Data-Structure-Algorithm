Name : Prem Atul Jethwa
UTA ID : 1001861810

The project is an implementation of the Sorting Algorithms created using HTML, CSS and Javascript

Table of Contents
1. Introduction
2. Technologies
3. Installation

#Introduction:
This project implements and compares the runtime of Sorting Algorithm for various input. Following are the implemented algorithms:
1.Mergesort
2.Heapsort
3.Quicksort (Last element pivot)
4.Quicksort (3 median approach)
5.Insertion sort
6.Selection sort
7.Bubble sort

These algorithms creates a random unsorted array/list, and user selects the type of sorting algorithm needed 
to sort the given array/list.

It also calculates the run time required for the algorithm to sort the array. 
Comparative study can also be done to compare the time complexity for each algorithm.

#Technologies
A list of technologies used within the project:
* [Visual Studio](https://visualstudio.microsoft.com/): Version 1.71.2
* [Chrome Browser]
* https://www.geeksforgeeks.org/sorting-algorithms/

#Installation
How to run the project
Steps to run the project:
1. Download or clone the project repository
2. Unzip the files and open the folder in Visual Studio Code
3. open index.html file
3. Go to Run tab -> Run  